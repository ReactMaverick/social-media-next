import styles from './imageDeviderSection.module.css';

export default function ImageDividerSection() {
    return (
        <div
            className={`${styles.imgDivider} d-none d-md-block`}
        />

    );
}
