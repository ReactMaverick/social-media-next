import styles from './peopleSignupText.module.css';

export default function PeopleSignupText() {
    return (
        <p className={styles.peopleSignupText}>
            People Already Signed Up
        </p>

    );
}
