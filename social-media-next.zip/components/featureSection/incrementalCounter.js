const IncrementalCounter = () => {
    return (
        <div id="incrementalCounter" className="incremental-counter" data-value="101242"></div>
    );
};

export default IncrementalCounter;
