import styles from './featureSectionHeader.module.css';

export default function FeatureSectionHeader() {
    return (

        <h1
            className={`${styles.sectionTitle} slideDown`}
        >
            social herd
        </h1>

    );
}
