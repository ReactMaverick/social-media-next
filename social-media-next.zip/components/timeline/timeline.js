export default function Timeline({ children }) {
    return (
        <div className="timeline">
            {children}
        </div>
    )
}