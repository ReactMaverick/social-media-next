
export default function TimelineContainer({ children }) {
    return (
        <div
            className="container"
        >
            {children}
        </div>
    )
}
