export default function NewsfeedMiddleColumn({ children }) {
    return (
        <div
            className={`col-md-7`}
        >
            {children}
        </div>
    );
}
