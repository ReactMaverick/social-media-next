import { getServerSession } from "next-auth";
import { authOptions, isAdmin } from "@/utils/auth";
import fs from 'fs'; // Use with caution and proper security

// Example: Allow specific file extensions and restrict access
const allowedExtensions = ['mp4', 'webm'];

export async function GET(req, res) {
    try {
        const session = await getServerSession(authOptions);
        if (session?.user) {

            const { searchParams } = new URL(req.url)
            const id = searchParams.get('id')

            // console.log("Id ==> ", id);

            if (!id || !allowedExtensions.includes(id.split('.').pop())) {
                return Response.json({ status: 400, message: 'Invalid asset identifier or extension' })
            }

            const filePath = `public/uploads/videos/${id}`; // Customize based on asset location

            // console.log("Filepath ==> ", filePath);

            // console.log("Is video exists ==> ", fs.existsSync(filePath));

            if (!fs.existsSync(filePath)) {
                return res.status(404).json({ message: 'Asset not found' });
            }

            const fileBuffer = fs.readFileSync(filePath); //Read file as buffer

            // console.log("File content ==> ", fileBuffer);

            const mimeType = `video/${filePath.split('.').pop()}`; // Set content type based on extension

            // console.log("Mime Type ==> ", mimeType);

            const blob = new Blob([fileBuffer], { type: mimeType });

            // console.log("Blob ==> ", blob);

            // Headers.set('Content-Type', mimeType)

            return new Response(blob, { headers: { 'content-type': mimeType } });

        } else {
            const errorResponse = new Response(
                JSON.stringify({ error: 'authentication Error' }),
                { status: 200, headers: { 'Content-Type': 'application/json' } }
            );
            return errorResponse;
        }
    } catch (error) {
        // console.error('Error creating post:', error);
        const internalServerErrorResponse = new Response(
            JSON.stringify({ error: 'Internal Server Error' }),
            { status: 500, headers: { 'Content-Type': 'application/json' } }
        );
        return internalServerErrorResponse;
    }

}
