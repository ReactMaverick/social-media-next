import LandingPage from '@/components/landingPage/landingPage';

export default function Home() {

    return (
        <>
            <LandingPage />
        </>
    )
}