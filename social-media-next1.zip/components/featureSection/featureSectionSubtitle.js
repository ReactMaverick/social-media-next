import styles from './featureSectionSubtitle.module.css';

export default function FeatureSectionSubtitle() {
    return (

        <h1
            className={`${styles.sectionSubtitle}`}
        >
            find awesome people like you
        </h1>

    );
}