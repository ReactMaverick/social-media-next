export default function TimelineMiddleColumn({ children }) {
    return (
        <div className={`col-md-7`}>
            {children}
        </div>
    )
}