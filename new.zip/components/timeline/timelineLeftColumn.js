export default function TimelineLeftColumn({ children }) {
    return (
        <div className={`col-md-3`}>
            {children}
        </div>
    )
}