import styles from './appDownloadSectionSubtitle.module.css';

export default function AppDownloadSectionSubtitle() {
    return (
        <h2
            className={styles.appDownloadSectionSubtitle}
        >
            stay connected anytime, anywhere
        </h2>

    );
}
